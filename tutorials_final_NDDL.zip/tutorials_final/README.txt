The order of the Jupyter noteboooks is the following:

1) LIF_neuron
2) 2_LIF_neurons_nest
3) Popultations_LIF_nest
4) LIF_evolution_and_LFP_simulation

The requirements to be able to run the tutorials is to have jupyter notebook installed.

How to install it? 
Downloading Anaconda will automaticlly install jupyter:
https://test-jupyter.readthedocs.io/en/latest/install.html

Brian should also be installed. How?
Once you have anaconda just type in your terminal:
conda install -c conda-forge brian2
And then type: 
conda install brian2
Brian is installed! 
more info at: https://brian2.readthedocs.io/en/stable/introduction/install.html


Nest should also be installed: 
https://nest-simulator.readthedocs.io/en/stable/installation/index.html

